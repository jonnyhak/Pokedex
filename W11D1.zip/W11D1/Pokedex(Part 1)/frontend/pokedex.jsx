import React from 'react';
import ReactDOM from 'react-dom';

document.addEventListener('DOMContentLoaded', () => {
  const store = configureStore();
  const root = document.getElementById('root');
  ReactDOM.render(<Root store={store} />, root);
})


// document.addEventListener('DOMContentLoaded', () => {
//   const rootEl = document.getElementById('root');
//   ReactDOM.render(<h1>Pokedex</h1>, rootEl);
// })

